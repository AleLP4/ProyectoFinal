package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import model.*;
import view.*;
/**
 *
 * @author Alessandro
 */
public class ControladorJuego implements ActionListener
{

    private GUIJuego gui;
    private PanelControl panelControl;
    private PanelTablero panelTablero;
    
    //clases de cordenadas
    private TableroCoordenadas tablero;
    private CoordenadasHome home;
    private Ficha jugador;
    private Ficha oponente;
    
    private Reglas reglas;
    
    private int colorJugadorId,colorOponenteId;
    
    private boolean turnoJugador = true;
    
    private Random random = new Random();
    private Colores colores = new Colores();
    private Dado dado = new Dado(random,0);
    

    public ControladorJuego(PanelControl panelControl, PanelTablero panelTablero, int pColorJugadorId) {
        this.panelControl = panelControl;
        this.panelTablero = panelTablero;
        this.colorJugadorId = colorJugadorId;
        
        tablero = new TableroCoordenadas();
        home = new CoordenadasHome();
        reglas = new Reglas();
       
        colorJugadorId = pColorJugadorId;
        if(colorJugadorId < 0)
        {
           colorJugadorId = 0; 
        }//fin if 
        if (colorJugadorId>3)
        {
            colorJugadorId=3;
        }//fin if 2
        
        
        if(colorJugadorId== 0)
        {
            pColorJugadorId = 1;
        }else if(colorJugadorId == 1)
        {
            pColorJugadorId= 0;
        }else if(colorJugadorId == 2)
        {
            pColorJugadorId= 3;
        }else if(colorJugadorId == 3)
        {
            pColorJugadorId= 2;
        }
        
        jugador = new Ficha(colorJugadorId);
        oponente = new Ficha(pColorJugadorId);
        
        panelControl.getBtnDado().addActionListener(this);
        panelControl.getBtnReinicio().addActionListener(this);
        
        
        Coordenadas cJugador = home.getHome(colorJugadorId);
        Coordenadas cOponente = home.getHome(pColorJugadorId);
        
        panelTablero.moverFicha(colorJugadorId,cJugador.getX(),cJugador.getY());
        panelTablero.moverFicha(pColorJugadorId,cOponente.getX(),cOponente.getY());

        panelControl.setFichaTurno("Turno:" + new Colores().idAtexto(colorJugadorId));
        panelControl.setNumeroDado(0);
        
        
        } //fin metodo constructor
    
    
        public void actualizarTurno ()
        {
            String nombreTurno;
            if (turnoJugador){
                nombreTurno= colores.idAtexto(colorJugadorId);
            } else {
                nombreTurno= colores.idAtexto(colorOponenteId);
            }
            panelControl.setFichaTurno(nombreTurno);
            
        }//fin actualizarTurno
        
        public void alternarTurno()
        {
            if(turnoJugador)
            {
                turnoJugador= false;
                
            }//fin if
            else
            {
             turnoJugador=true;   
            }
        }//finalternarTurno
        
        
        public void actualizarHome()
        {
            Coordenadas cJugador = home.getHome(colorJugadorId);
            Coordenadas cOponente = home.getHome(colorOponenteId);
        
            panelTablero.moverFicha(colorJugadorId,cJugador.getX(),cJugador.getY());
            panelTablero.moverFicha(colorOponenteId,cOponente.getX(),cOponente.getY());

        }//fin actualizar
    
        
        public void reiniciar()
        {
            jugador.reset();
            oponente.reset();
            panelControl.setNumeroDado(0);
            actualizarHome();
            actualizarTurno();
        }
        
        
        
        public void jugar()
        {
            int informacion = dado.tirada();
            panelControl.setNumeroDado(informacion);

            Ficha actual;

            int colorId;

            if(turnoJugador)
            {
                actual=jugador;
                colorId = colorJugadorId;
            }//fin if
            else
            {
                actual=oponente;
                colorId=colorOponenteId;
            }

            if(actual.isPoseInicial())
            {
                if(reglas.salir(informacion))
                {
                    //iactual es clase ficha
                    int exit = reglas.salidaId(colorId);
                    actual.setIndice(exit);
                    actual.setPoseInicial(false);
                    actual.setCaminoWin(false);
                    actual.setPasoWin(0);
                    pintarRecorrido(actual,colorId);
                }//fi if2
                else
                {
                    alternarTurno();
                    actualizarTurno();
                    return;
                }/* fin else*/
            }//fin if
            
            
                if(!actual.isCaminoWin())
                {
                    int d= actual.getIndice();
                    
                    int dFinal= reglas.avanzar(d,informacion);
                    if(reglas.entradaWin(colorId, dFinal))
                    {
                      actual.setCaminoWin(true);
                      actual.setPasoWin(0);
                      
                    }
                    alternarTurno();
                    actualizarTurno();
                    return;
                }//fin if
            
            int newSteps = actual.isPasoWin()+informacion;
            actual.setPasoWin(newSteps);
            pintarCaminoWin(actual,colorId,informacion);
            
            alternarTurno();
            actualizarTurno();
            
            //aqui debe haber una verificacion de que la ficha esta en la meta
            //y mandar un mensaje con un JOptionPane de gano
            }//fin jugar
        
        
        public void pintarRecorrido (Ficha ficha, int colorId)
        {
            Coordenadas c = tablero.getPosicion(ficha.getIndice());
            panelTablero.moverFicha(colorId, c.getX(), c.getY());
        }//fin pintarRecorrido 
        
        
        
        public void pintarCaminoWin(Ficha ficha,int colorId, int steps)
        {
            Coordenadas c = tablero.getCaminoWin(colorId,steps);
            panelTablero.moverFicha(colorId, c.getX(), c.getY());
        }//fin
        
        
        public void actionPerformed(ActionEvent e)
        {
           Object x = e.getSource();
           if(x== panelControl.getBtnDado())
            {
                jugar();
                
            }else if(x== panelControl.getBtnReinicio())
            {
                reiniciar();
            }
        }//fin actionPerformed
    
}//fin ControladorJuego
